CREATE DATABASE "Proyecto" 
CREATE TABLE avion (
    av_id integer NOT NULL,
    av_nombre character varying(50) NOT NULL,
    av_color character varying(50) NOT NULL,
    fk_avion_modelo integer
);

CREATE TABLE beneficiario (
    be_id integer NOT NULL,
    be_nombre character varying(50) NOT NULL,
    be_tipo character varying(50),
    fk_beneficiario_empleado integer NOT NULL
);

CREATE TABLE capacidad (
    ca_id numeric NOT NULL,
    ca_cantidad numeric NOT NULL,
    ca_numeroclase numeric,
    ca_tipoclase character varying(50),
    fk_capacidad_modelo integer NOT NULL
);

CREATE TABLE cliente (
    cli_id integer NOT NULL,
    cli_cedula integer NOT NULL,
    cli_nombre character varying(50) NOT NULL,
    cli_montoac integer,
    cli_fe_in date,
    cli_pg_web character varying(50),
    fk_cliente_lugar integer
);

CREATE TABLE compra (
    co_id integer NOT NULL,
    co_fe_sol date NOT NULL,
    co_fe_fin date,
    co_monto_total real,
    fk_compra_proveedor integer,
    fk_compra_tipopago integer
);

CREATE TABLE contacto (
    co_id integer NOT NULL,
    co_correo character varying(50),
    co_telefono character varying(50),
    co_redso character varying(50),
    fk_contacto_empleado integer,
    fk_contacto_cliente integer,
    fk_contacto_proveedor integer
);

CREATE TABLE empleado (
    em_id integer NOT NULL,
    em_nombre character varying(50) NOT NULL,
    em_apellido character varying(50) NOT NULL,
    em_fe_ingreso date NOT NULL,
    em_titulacion character varying(50),
    em_experiencia character varying(50),
    fk_empleado_fabricacion integer,
    fk_empleado_lugar integer,
    em_cedula integer NOT NULL
);

CREATE TABLE fabricacion (
    fa_id integer NOT NULL,
    fa_nombre character varying(50) NOT NULL,
    fa_fe_inicio timestamp without time zone NOT NULL,
    fa_fe_fin_aprox timestamp without time zone,
    fa_fe_fin timestamp without time zone,
    fa_conclusion character varying(50)
);

CREATE TABLE historico (
    hi_id integer NOT NULL,
    hi_fe_inicio timestamp without time zone NOT NULL,
    hi_fe_fin_aprox timestamp without time zone,
    hi_fe_fin timestamp without time zone,
    hi_resultado character varying(50),
    fk_historico_prueba integer NOT NULL
);

CREATE TABLE inventario (
    in_id integer NOT NULL,
    in_cantidad integer NOT NULL,
    fk_inventario_pieza integer,
    fk_inventario_zona integer,
    fk_inventario_material integer
);

CREATE TABLE lugar (
    lu_id numeric NOT NULL,
    lu_nombre character varying(50) NOT NULL,
    lu_tipo character varying(50) NOT NULL,
    fk_lugar numeric
);

CREATE TABLE m_p (
    mp_id integer NOT NULL,
    mp_monto_unidad real NOT NULL,
    mp_cantidad integer,
    fk_mp_material integer,
    fk_mp_compra integer
);

CREATE TABLE material (
    ma_id integer NOT NULL,
    ma_nombre character varying(50) NOT NULL,
    fk_material_zona_en integer NOT NULL,
    fk_material_zona_re integer
);

CREATE TABLE modelo (
    mo_id numeric NOT NULL,
    mo_nombre character varying(50) NOT NULL
);

CREATE TABLE p_c (
    pc_valor character varying(50),
    fk_pc_modelo numeric NOT NULL,
    fk_pc_particularidad numeric NOT NULL,
    pc_id numeric NOT NULL
);

CREATE TABLE particularidad (
    pa_id numeric NOT NULL,
    pa_nombre character varying(50) NOT NULL
);

CREATE TABLE pieza (
    pi_id integer NOT NULL,
    pi_mombre character varying(50) NOT NULL,
    pi_tipo character varying(50) NOT NULL,
    fk_pieza_modelo integer NOT NULL,
    fk_pieza integer,
    fk_pieza_zf integer
);

CREATE TABLE pmotor (
    pm_id numeric NOT NULL,
    pm_nombre character varying(50) NOT NULL,
    pm_tipo character varying(50) NOT NULL,
    fk_motor_modelo numeric
);

CREATE TABLE pri_r (
    prir_id integer NOT NULL,
    fk_prir_rol integer,
    fk_prir_privilegio integer
);

CREATE TABLE privilegio (
    pri_id integer NOT NULL,
    pri_nombre character varying(50) NOT NULL
);

CREATE TABLE proveedor (
    pro_id integer NOT NULL,
    pro_cedula integer NOT NULL,
    pro_nombre character varying(50) NOT NULL,
    pro_montoac integer,
    pro_fe_in date,
    pro_pg_web character varying(50),
    fk_proveedor_lugar integer
);

CREATE TABLE prueba (
    pr_id integer NOT NULL,
    pr_nombre character varying(50) NOT NULL,
    pr_comentario character varying(50),
    fk_prueba_pieza integer,
    fk_prueba_material integer,
    fk_prueba_empleado integer
);

CREATE TABLE rol (
    ro_id integer NOT NULL,
    ro_nombre character varying(50) NOT NULL
);

CREATE TABLE sede (
    se_id integer NOT NULL,
    se_nombre character varying(50) NOT NULL,
    fk_sede_lugar integer,
    fk_sede_empleado integer
);

CREATE TABLE solicitud (
    so_id integer NOT NULL,
    so_costo real NOT NULL,
    so_fecha date NOT NULL,
    so_catidad integer NOT NULL,
    so_total real,
    fk_solicitud_cliente integer,
    fk_solicitud_avion integer
);

CREATE TABLE tipopago (
    ti_id integer NOT NULL,
    ch_banco character varying(50),
    ch_numero integer,
    ch_numcuenta integer,
    cr_tipo character varying(50),
    cr_banco character varying(50),
    cr_numero integer,
    cr_fe_vto date,
    tr_banco character varying(50),
    tr_numero integer,
    de_banco character varying(50),
    de_numero integer,
    ti_efectivo integer
);

CREATE TABLE usuario (
    us_user character varying(50) NOT NULL,
    us_clave character varying(50) NOT NULL,
    fk_usuario_empleado integer,
    fk_usuario_cliente integer,
    fk_usuario_proveedor integer,
    fk_usuario_rol integer
);

CREATE TABLE venta (
    ve_id integer NOT NULL,
    ve_fe_sol date NOT NULL,
    ve_fe_fin date,
    ve_monto real,
    fk_venta_solicitud integer
);

CREATE TABLE z_f (
    zf_id integer NOT NULL,
    fk_zf_fabricacion integer,
    fk_zf_zona integer
);

CREATE TABLE zona (
    zo_id integer NOT NULL,
    zo_nombre character varying(50) NOT NULL,
    fk_zona_avion integer,
    fk_zona_sede integer,
    fk_zona_empleado integer
);