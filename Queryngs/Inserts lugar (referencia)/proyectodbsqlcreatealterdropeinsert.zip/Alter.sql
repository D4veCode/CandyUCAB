
ALTER TABLE ONLY beneficiario
    ADD CONSTRAINT beneficiario_pkey PRIMARY KEY (be_id);
ALTER TABLE ONLY capacidad
    ADD CONSTRAINT capacidad_pkey PRIMARY KEY (ca_id);
ALTER TABLE ONLY cliente
    ADD CONSTRAINT cliente_pkey PRIMARY KEY (cli_id);
ALTER TABLE ONLY compra
    ADD CONSTRAINT compra_pkey PRIMARY KEY (co_id);
ALTER TABLE ONLY contacto
    ADD CONSTRAINT contacto_pkey PRIMARY KEY (co_id);
ALTER TABLE ONLY empleado
    ADD CONSTRAINT empleado_pkey PRIMARY KEY (em_id);
ALTER TABLE ONLY fabricacion
    ADD CONSTRAINT fabricacion_pkey PRIMARY KEY (fa_id);
ALTER TABLE ONLY historico
    ADD CONSTRAINT historico_pkey PRIMARY KEY (hi_id);
ALTER TABLE ONLY inventario
    ADD CONSTRAINT inventario_pkey PRIMARY KEY (in_id);
ALTER TABLE ONLY lugar
    ADD CONSTRAINT lugar_pkey PRIMARY KEY (lu_id);
ALTER TABLE ONLY m_p
    ADD CONSTRAINT m_p_pkey PRIMARY KEY (mp_id);
ALTER TABLE ONLY material
    ADD CONSTRAINT material_pkey PRIMARY KEY (ma_id);
ALTER TABLE ONLY p_c
    ADD CONSTRAINT p_c_pkey PRIMARY KEY (pc_id);
ALTER TABLE ONLY particularidad
    ADD CONSTRAINT particularidad_pkey PRIMARY KEY (pa_id);
ALTER TABLE ONLY pieza
    ADD CONSTRAINT pieza_pkey PRIMARY KEY (pi_id);
ALTER TABLE ONLY avion
    ADD CONSTRAINT pk_av PRIMARY KEY (av_id);
ALTER TABLE ONLY modelo
    ADD CONSTRAINT pk_mo PRIMARY KEY (mo_id);
ALTER TABLE ONLY pmotor
    ADD CONSTRAINT pmotor_pkey PRIMARY KEY (pm_id);
ALTER TABLE ONLY pri_r
    ADD CONSTRAINT pri_r_pkey PRIMARY KEY (prir_id);
ALTER TABLE ONLY privilegio
    ADD CONSTRAINT privilegio_pkey PRIMARY KEY (pri_id);
ALTER TABLE ONLY proveedor
    ADD CONSTRAINT proveedor_pkey PRIMARY KEY (pro_id);
ALTER TABLE ONLY prueba
    ADD CONSTRAINT prueba_pkey PRIMARY KEY (pr_id);
ALTER TABLE ONLY rol
    ADD CONSTRAINT rol_pkey PRIMARY KEY (ro_id);
ALTER TABLE ONLY sede
    ADD CONSTRAINT sede_pkey PRIMARY KEY (se_id);
ALTER TABLE ONLY solicitud
    ADD CONSTRAINT solicitud_pkey PRIMARY KEY (so_id);
ALTER TABLE ONLY tipopago
    ADD CONSTRAINT tipopago_pkey PRIMARY KEY (ti_id);
ALTER TABLE ONLY usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (us_user);
ALTER TABLE ONLY venta
    ADD CONSTRAINT venta_pkey PRIMARY KEY (ve_id);
ALTER TABLE ONLY z_f
    ADD CONSTRAINT z_f_pkey PRIMARY KEY (zf_id);
ALTER TABLE ONLY zona
    ADD CONSTRAINT zona_pkey PRIMARY KEY (zo_id);

ALTER TABLE ONLY avion
    ADD CONSTRAINT fk_avion_modelo FOREIGN KEY (fk_avion_modelo) REFERENCES modelo(mo_id);

ALTER TABLE ONLY beneficiario
    ADD CONSTRAINT fk_beneficiario_empleado FOREIGN KEY (fk_beneficiario_empleado) REFERENCES empleado(em_id);

ALTER TABLE ONLY capacidad
    ADD CONSTRAINT fk_capacidad_modelo FOREIGN KEY (fk_capacidad_modelo) REFERENCES modelo(mo_id);

ALTER TABLE ONLY cliente
    ADD CONSTRAINT fk_cliente_lugar FOREIGN KEY (fk_cliente_lugar) REFERENCES lugar(lu_id);

ALTER TABLE ONLY compra
    ADD CONSTRAINT fk_compra_proveedor FOREIGN KEY (fk_compra_proveedor) REFERENCES proveedor(pro_id);

ALTER TABLE ONLY compra
    ADD CONSTRAINT fk_compra_tipopago FOREIGN KEY (fk_compra_tipopago) REFERENCES tipopago(ti_id);

ALTER TABLE ONLY contacto
    ADD CONSTRAINT fk_contacto_cliente FOREIGN KEY (fk_contacto_cliente) REFERENCES cliente(cli_id);

ALTER TABLE ONLY contacto
    ADD CONSTRAINT fk_contacto_empleado FOREIGN KEY (fk_contacto_empleado) REFERENCES empleado(em_id);

ALTER TABLE ONLY contacto
    ADD CONSTRAINT fk_contacto_proveedor FOREIGN KEY (fk_contacto_proveedor) REFERENCES proveedor(pro_id);

ALTER TABLE ONLY empleado
    ADD CONSTRAINT fk_empleado_fabricacion FOREIGN KEY (fk_empleado_fabricacion) REFERENCES fabricacion(fa_id);

ALTER TABLE ONLY empleado
    ADD CONSTRAINT fk_empleado_lugar FOREIGN KEY (fk_empleado_lugar) REFERENCES lugar(lu_id);

ALTER TABLE ONLY historico
    ADD CONSTRAINT fk_historico_prueba FOREIGN KEY (fk_historico_prueba) REFERENCES prueba(pr_id);

ALTER TABLE ONLY inventario
    ADD CONSTRAINT fk_inventario_pieza FOREIGN KEY (fk_inventario_pieza) REFERENCES pieza(pi_id);

ALTER TABLE ONLY inventario
    ADD CONSTRAINT fk_inventario_zona FOREIGN KEY (fk_inventario_zona) REFERENCES zona(zo_id);

ALTER TABLE ONLY lugar
    ADD CONSTRAINT fk_lugar FOREIGN KEY (fk_lugar) REFERENCES lugar(lu_id);

ALTER TABLE ONLY material
    ADD CONSTRAINT fk_material_zon_en FOREIGN KEY (fk_material_zona_en) REFERENCES zona(zo_id);

ALTER TABLE ONLY material
    ADD CONSTRAINT fk_material_zon_re FOREIGN KEY (fk_material_zona_re) REFERENCES zona(zo_id);

ALTER TABLE ONLY pmotor
    ADD CONSTRAINT fk_modelo FOREIGN KEY (fk_motor_modelo) REFERENCES modelo(mo_id);

ALTER TABLE ONLY pmotor
    ADD CONSTRAINT fk_motor_modelo FOREIGN KEY (fk_motor_modelo) REFERENCES modelo(mo_id);

ALTER TABLE ONLY m_p
    ADD CONSTRAINT fk_mp_compra FOREIGN KEY (fk_mp_compra) REFERENCES compra(co_id);

ALTER TABLE ONLY m_p
    ADD CONSTRAINT fk_mp_material FOREIGN KEY (fk_mp_material) REFERENCES material(ma_id);

ALTER TABLE ONLY p_c
    ADD CONSTRAINT fk_pc_modelo FOREIGN KEY (fk_pc_modelo) REFERENCES modelo(mo_id);

ALTER TABLE ONLY p_c
    ADD CONSTRAINT fk_pc_particularidad FOREIGN KEY (fk_pc_particularidad) REFERENCES particularidad(pa_id);

ALTER TABLE ONLY pieza
    ADD CONSTRAINT fk_pieza FOREIGN KEY (fk_pieza) REFERENCES pieza(pi_id);

ALTER TABLE ONLY pieza
    ADD CONSTRAINT fk_pieza_modelo FOREIGN KEY (fk_pieza_modelo) REFERENCES modelo(mo_id);

ALTER TABLE ONLY pieza
    ADD CONSTRAINT fk_pieza_zf FOREIGN KEY (fk_pieza_zf) REFERENCES z_f(zf_id);

ALTER TABLE ONLY pri_r
    ADD CONSTRAINT fk_prir_privilegio FOREIGN KEY (fk_prir_privilegio) REFERENCES privilegio(pri_id);

ALTER TABLE ONLY pri_r
    ADD CONSTRAINT fk_prir_rol FOREIGN KEY (fk_prir_rol) REFERENCES rol(ro_id);

ALTER TABLE ONLY proveedor
    ADD CONSTRAINT fk_proveedor_lugar FOREIGN KEY (fk_proveedor_lugar) REFERENCES lugar(lu_id);

ALTER TABLE ONLY prueba
    ADD CONSTRAINT fk_prueba_empleado FOREIGN KEY (fk_prueba_empleado) REFERENCES empleado(em_id);

ALTER TABLE ONLY prueba
    ADD CONSTRAINT fk_prueba_material FOREIGN KEY (fk_prueba_material) REFERENCES material(ma_id);

ALTER TABLE ONLY prueba
    ADD CONSTRAINT fk_prueba_pieza FOREIGN KEY (fk_prueba_pieza) REFERENCES pieza(pi_id);

ALTER TABLE ONLY sede
    ADD CONSTRAINT fk_sede_empleado FOREIGN KEY (fk_sede_empleado) REFERENCES empleado(em_id);

ALTER TABLE ONLY sede
    ADD CONSTRAINT fk_sede_lugar FOREIGN KEY (fk_sede_lugar) REFERENCES lugar(lu_id);

ALTER TABLE ONLY solicitud
    ADD CONSTRAINT fk_solicitud_avion FOREIGN KEY (fk_solicitud_avion) REFERENCES avion(av_id);

ALTER TABLE ONLY solicitud
    ADD CONSTRAINT fk_solicitud_cliente FOREIGN KEY (fk_solicitud_cliente) REFERENCES cliente(cli_id);

ALTER TABLE ONLY usuario
    ADD CONSTRAINT fk_usuario_cliente FOREIGN KEY (fk_usuario_cliente) REFERENCES cliente(cli_id);

ALTER TABLE ONLY usuario
    ADD CONSTRAINT fk_usuario_empleado FOREIGN KEY (fk_usuario_empleado) REFERENCES empleado(em_id);

ALTER TABLE ONLY usuario
    ADD CONSTRAINT fk_usuario_proveedor FOREIGN KEY (fk_usuario_proveedor) REFERENCES proveedor(pro_id);

ALTER TABLE ONLY usuario
    ADD CONSTRAINT fk_usuario_rol FOREIGN KEY (fk_usuario_rol) REFERENCES rol(ro_id);

ALTER TABLE ONLY venta
    ADD CONSTRAINT fk_venta_solicitud FOREIGN KEY (fk_venta_solicitud) REFERENCES solicitud(so_id);

ALTER TABLE ONLY z_f
    ADD CONSTRAINT fk_zf_fabricacion FOREIGN KEY (fk_zf_fabricacion) REFERENCES fabricacion(fa_id);

ALTER TABLE ONLY z_f
    ADD CONSTRAINT fk_zf_zona FOREIGN KEY (fk_zf_zona) REFERENCES zona(zo_id);

ALTER TABLE ONLY zona
    ADD CONSTRAINT fk_zona_avion FOREIGN KEY (fk_zona_avion) REFERENCES avion(av_id);

ALTER TABLE ONLY zona
    ADD CONSTRAINT fk_zona_empleado FOREIGN KEY (fk_zona_empleado) REFERENCES empleado(em_id);

ALTER TABLE ONLY zona
    ADD CONSTRAINT fk_zona_sede FOREIGN KEY (fk_zona_sede) REFERENCES sede(se_id);
