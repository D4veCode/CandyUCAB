DROP TABLE public.avion;

DROP TABLE public.beneficiario;

DROP TABLE public.capacidad;

DROP TABLE public.cliente;

DROP TABLE public.compra;

DROP TABLE public.contacto;

DROP TABLE public.empleado;

DROP TABLE public.fabricacion;

DROP TABLE public.historico;

DROP TABLE public.inventario;

DROP TABLE public.lugar;

DROP TABLE public.m_p;

DROP TABLE public.material;

DROP TABLE public.modelo;

DROP TABLE public.p_c;

DROP TABLE public.particularidad;

DROP TABLE public.pieza;

DROP TABLE public.pmotor;

DROP TABLE public.pri_r;

DROP TABLE public.privilegio;

DROP TABLE public.proveedor;

DROP TABLE public.prueba;

DROP TABLE public.rol;

DROP TABLE public.sede;

DROP TABLE public.solicitud;

DROP TABLE public.tipopago;

DROP TABLE public.usuario;

DROP TABLE public.venta;

DROP TABLE public.z_f;

DROP TABLE public.zona;

DROP DATABASE "Proyecto";
